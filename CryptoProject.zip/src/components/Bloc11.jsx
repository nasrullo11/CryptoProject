import React from 'react'
import Bloc1 from "./Bloc1"
import Bloc2 from "./Bloc2"
import Bloc3 from "./Bloc3"
import Bloc4 from "./Bloc4"
import Bloc5 from "./Bloc5"
import Bloc6 from "./Bloc6"
import Bloc7 from "./Bloc7"
import Bloc8 from "./Bloc8"
import Bloc9 from "./Bloc9"
import Bloc10 from "./Bloc10"

const Bloc11 = () => {
  return (
    <div>
        <Bloc2 />
        <Bloc3 />
        <Bloc4 />
        <Bloc5 />
        <Bloc6 />
        <Bloc7 />
        <Bloc8 />
    </div>
  )
}

export default Bloc11