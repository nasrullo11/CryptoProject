export const handleType = (type, payload) => ({
    type: type,
    payload: payload,
})
